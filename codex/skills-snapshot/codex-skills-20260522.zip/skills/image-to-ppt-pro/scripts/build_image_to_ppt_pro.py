#!/usr/bin/env python3
"""Plan-based image-to-editable-PPT builder for image-to-ppt-pro.

The script intentionally uses a small semantic JSON format instead of guessing
everything automatically. OCR and CV can draft the plan, but final quality comes
from proofed text, clean asset crops, and deterministic regeneration.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError as exc:  # pragma: no cover - runtime dependency message
    raise SystemExit("Missing Pillow. Install with: python -m pip install Pillow") from exc


EMU_PER_INCH = 914400
DEFAULT_SLIDE_WIDTH_IN = 13.333333
DEFAULT_SLIDE_HEIGHT_IN = 7.5
ALLOWED_TYPES = {
    "text",
    "rect",
    "line",
    "circle",
    "image",
    "table",
    "polygon",
    "parallelogram",
}


@dataclass(frozen=True)
class Scale:
    canvas_w: float
    canvas_h: float
    slide_w_emu: int
    slide_h_emu: int

    def x(self, value: float) -> int:
        return int(round(value / self.canvas_w * self.slide_w_emu))

    def y(self, value: float) -> int:
        return int(round(value / self.canvas_h * self.slide_h_emu))

    def w(self, value: float) -> int:
        return int(round(value / self.canvas_w * self.slide_w_emu))

    def h(self, value: float) -> int:
        return int(round(value / self.canvas_h * self.slide_h_emu))

    def pt(self, px: float) -> float:
        return px * 72.0 / 96.0


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_color(value: Any, default: str = "#000000") -> str:
    if value is None or value == "none":
        return "none"
    if isinstance(value, str) and value.startswith("#") and len(value) in {4, 7}:
        if len(value) == 4:
            return "#" + "".join(ch * 2 for ch in value[1:])
        return value
    return default


def rgb_tuple(color: str, default: tuple[int, int, int] = (0, 0, 0)) -> tuple[int, int, int]:
    color = normalize_color(color)
    if color == "none":
        return default
    return tuple(int(color[i : i + 2], 16) for i in (1, 3, 5))


def load_plan(path: Path) -> dict[str, Any]:
    plan = read_json(path)
    if "canvas" not in plan:
        raise ValueError("layout plan requires a canvas object")
    canvas = plan["canvas"]
    for key in ("width", "height"):
        if key not in canvas:
            raise ValueError(f"canvas.{key} is required")
    plan.setdefault("schema_version", "image-to-ppt-pro/v1")
    plan.setdefault("assets", [])
    plan.setdefault("elements", [])
    ids: set[str] = set()
    for element in plan["elements"]:
        etype = element.get("type")
        if etype not in ALLOWED_TYPES:
            raise ValueError(f"Unsupported element type: {etype!r}")
        eid = element.get("id")
        if eid:
            if eid in ids:
                raise ValueError(f"Duplicate element id: {eid}")
            ids.add(eid)
    return plan


def sorted_elements(plan: dict[str, Any]) -> list[dict[str, Any]]:
    return sorted(plan.get("elements", []), key=lambda item: (item.get("z", 0), item.get("id", "")))


def asset_map(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {item["id"]: item for item in plan.get("assets", []) if "id" in item}


def apply_near_white_transparency(image: Image.Image, threshold: int = 245) -> Image.Image:
    rgba = image.convert("RGBA")
    pixels = rgba.load()
    width, height = rgba.size
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            if r >= threshold and g >= threshold and b >= threshold:
                pixels[x, y] = (r, g, b, 0)
    return rgba


def crop_box_with_padding(box: Iterable[float], padding: int, image_size: tuple[int, int]) -> tuple[int, int, int, int]:
    x, y, w, h = [int(round(float(v))) for v in box]
    left = max(0, x - padding)
    top = max(0, y - padding)
    right = min(image_size[0], x + w + padding)
    bottom = min(image_size[1], y + h + padding)
    if right <= left or bottom <= top:
        raise ValueError(f"Invalid source_box after padding: {box}")
    return left, top, right, bottom


def crop_assets(plan: dict[str, Any], source: Path | None, workdir: Path) -> list[Path]:
    assets_dir = workdir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []
    source_image = Image.open(source).convert("RGBA") if source else None
    for asset in plan.get("assets", []):
        file_value = asset.get("file")
        if not file_value:
            continue
        target = workdir / file_value
        if not target.is_absolute():
            target = workdir / file_value
        target.parent.mkdir(parents=True, exist_ok=True)

        if "source_box" in asset:
            if source_image is None:
                raise ValueError(f"Asset {asset.get('id')} has source_box but no --source was provided")
            pad = int(asset.get("padding", 0))
            crop_box = crop_box_with_padding(asset["source_box"], pad, source_image.size)
            cropped = source_image.crop(crop_box)
            if asset.get("transparent_near_white"):
                threshold = int(asset.get("near_white_threshold", 245))
                cropped = apply_near_white_transparency(cropped, threshold)
            cropped.save(target)
            created.append(target)
        elif "copy_from" in asset:
            src = Path(asset["copy_from"])
            shutil.copy2(src, target)
            created.append(target)
    return created


def points_attr(points: list[list[float]]) -> str:
    return " ".join(f"{x:.2f},{y:.2f}" for x, y in points)


def write_svg(plan: dict[str, Any], workdir: Path, out: Path) -> None:
    canvas = plan["canvas"]
    width = float(canvas["width"])
    height = float(canvas["height"])
    bg = normalize_color(canvas.get("background", "#ffffff"), "#ffffff")
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:g}" height="{height:g}" viewBox="0 0 {width:g} {height:g}">',
        f'<rect width="{width:g}" height="{height:g}" fill="{bg}"/>',
    ]
    assets = asset_map(plan)
    for element in sorted_elements(plan):
        etype = element["type"]
        fill = normalize_color(element.get("fill", "none"))
        stroke = normalize_color(element.get("stroke", "none"))
        sw = float(element.get("stroke_width", 0 if stroke == "none" else 1))
        if etype == "rect":
            lines.append(
                f'<rect x="{element["x"]}" y="{element["y"]}" width="{element["w"]}" height="{element["h"]}" '
                f'fill="{fill}" stroke="{stroke}" stroke-width="{sw:g}"/>'
            )
        elif etype == "line":
            lines.append(
                f'<line x1="{element["x1"]}" y1="{element["y1"]}" x2="{element["x2"]}" y2="{element["y2"]}" '
                f'stroke="{stroke}" stroke-width="{sw:g}"/>'
            )
        elif etype == "circle":
            lines.append(
                f'<circle cx="{element["cx"]}" cy="{element["cy"]}" r="{element["r"]}" '
                f'fill="{fill}" stroke="{stroke}" stroke-width="{sw:g}"/>'
            )
        elif etype == "polygon":
            lines.append(
                f'<polygon points="{points_attr(element["points"])}" fill="{fill}" stroke="{stroke}" stroke-width="{sw:g}"/>'
            )
        elif etype == "parallelogram":
            x = float(element["x"])
            y = float(element["y"])
            w = float(element["w"])
            h = float(element["h"])
            skew = float(element.get("skew", 0))
            pts = [[x + skew, y], [x + w + skew, y], [x + w, y + h], [x, y + h]]
            lines.append(f'<polygon points="{points_attr(pts)}" fill="{fill}" stroke="{stroke}" stroke-width="{sw:g}"/>')
        elif etype == "image":
            asset = assets.get(element.get("asset_id"), {})
            href = asset.get("file") or element.get("file")
            if href:
                lines.append(
                    f'<image href="{href}" x="{element["x"]}" y="{element["y"]}" '
                    f'width="{element["w"]}" height="{element["h"]}" preserveAspectRatio="none"/>'
                )
        elif etype == "text":
            color = normalize_color(element.get("color", "#000000"))
            weight = "700" if element.get("bold") else "400"
            family = element.get("font_family", "Microsoft YaHei")
            size = float(element.get("font_size", 16))
            x = float(element["x"])
            y = float(element["y"]) + size
            for idx, line in enumerate(str(element.get("text", "")).splitlines() or [""]):
                dy = idx * size * float(element.get("line_spacing", 1.15))
                escaped = (
                    line.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                )
                lines.append(
                    f'<text x="{x:g}" y="{y + dy:g}" font-family="{family}" font-size="{size:g}" '
                    f'font-weight="{weight}" fill="{color}">{escaped}</text>'
                )
        elif etype == "table":
            draw_table_svg(lines, element)
    lines.append("</svg>")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines), encoding="utf-8")


def draw_table_svg(lines: list[str], table: dict[str, Any]) -> None:
    x = float(table["x"])
    y = float(table["y"])
    cols = int(table["cols"])
    rows = int(table["rows"])
    total_w = float(table["w"])
    total_h = float(table["h"])
    col_widths = table.get("col_widths") or [total_w / cols] * cols
    row_heights = table.get("row_heights") or [total_h / rows] * rows
    border = normalize_color(table.get("border", "#999999"))
    fill = normalize_color(table.get("fill", "#ffffff"))
    header_fill = normalize_color(table.get("header_fill", fill))
    alt_fill = normalize_color(table.get("alt_fill", fill))
    font_size = float(table.get("font_size", 14))
    family = table.get("font_family", "Microsoft YaHei")
    cell_text = table.get("cell_text", [])
    yy = y
    for r in range(rows):
        xx = x
        for c in range(cols):
            cw = float(col_widths[c])
            rh = float(row_heights[r])
            bg = header_fill if r == 0 else (alt_fill if r % 2 == 0 else fill)
            lines.append(f'<rect x="{xx:g}" y="{yy:g}" width="{cw:g}" height="{rh:g}" fill="{bg}" stroke="{border}" stroke-width="1"/>')
            text = ""
            if r < len(cell_text) and c < len(cell_text[r]):
                text = str(cell_text[r][c])
            escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            lines.append(
                f'<text x="{xx + 8:g}" y="{yy + font_size + 8:g}" font-family="{family}" '
                f'font-size="{font_size:g}" fill="{normalize_color(table.get("color", "#000000"))}">{escaped}</text>'
            )
            xx += cw
        yy += float(row_heights[r])


def preview_font(element: dict[str, Any]) -> ImageFont.ImageFont:
    size = int(round(float(element.get("font_size", 16))))
    candidates = [
        r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\msyhbd.ttc" if element.get("bold") else r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\arial.ttf",
    ]
    for path in candidates:
        if path and Path(path).exists():
            try:
                return ImageFont.truetype(path, size=size)
            except OSError:
                pass
    return ImageFont.load_default()


def write_preview(plan: dict[str, Any], workdir: Path, out: Path) -> None:
    canvas = plan["canvas"]
    width = int(round(float(canvas["width"])))
    height = int(round(float(canvas["height"])))
    image = Image.new("RGBA", (width, height), rgb_tuple(canvas.get("background", "#ffffff"), (255, 255, 255)) + (255,))
    draw = ImageDraw.Draw(image)
    assets = asset_map(plan)
    for element in sorted_elements(plan):
        etype = element["type"]
        if etype == "rect":
            draw.rectangle(
                [element["x"], element["y"], element["x"] + element["w"], element["y"] + element["h"]],
                fill=rgb_tuple(element.get("fill", "#ffffff")),
                outline=None if element.get("stroke", "none") == "none" else rgb_tuple(element.get("stroke")),
                width=int(element.get("stroke_width", 1)),
            )
        elif etype == "line":
            draw.line(
                [element["x1"], element["y1"], element["x2"], element["y2"]],
                fill=rgb_tuple(element.get("stroke", "#000000")),
                width=max(1, int(element.get("stroke_width", 1))),
            )
        elif etype == "circle":
            cx, cy, r = float(element["cx"]), float(element["cy"]), float(element["r"])
            draw.ellipse(
                [cx - r, cy - r, cx + r, cy + r],
                fill=rgb_tuple(element.get("fill", "#ffffff")),
                outline=None if element.get("stroke", "none") == "none" else rgb_tuple(element.get("stroke")),
                width=int(element.get("stroke_width", 1)),
            )
        elif etype == "polygon":
            draw.polygon([tuple(pt) for pt in element["points"]], fill=rgb_tuple(element.get("fill", "#ffffff")))
        elif etype == "parallelogram":
            x, y, w, h = [float(element[key]) for key in ("x", "y", "w", "h")]
            skew = float(element.get("skew", 0))
            pts = [(x + skew, y), (x + w + skew, y), (x + w, y + h), (x, y + h)]
            draw.polygon(pts, fill=rgb_tuple(element.get("fill", "#ffffff")))
        elif etype == "image":
            asset = assets.get(element.get("asset_id"), {})
            href = asset.get("file") or element.get("file")
            if href:
                asset_path = workdir / href
                if asset_path.exists():
                    pic = Image.open(asset_path).convert("RGBA").resize((int(element["w"]), int(element["h"])))
                    image.alpha_composite(pic, (int(element["x"]), int(element["y"])))
        elif etype == "text":
            font = preview_font(element)
            color = rgb_tuple(element.get("color", "#000000"))
            x, y = int(element["x"]), int(element["y"])
            line_step = int(float(element.get("font_size", 16)) * float(element.get("line_spacing", 1.15)))
            for idx, line in enumerate(str(element.get("text", "")).splitlines() or [""]):
                draw.text((x, y + idx * line_step), line, font=font, fill=color)
        elif etype == "table":
            draw_table_preview(draw, element)
    out.parent.mkdir(parents=True, exist_ok=True)
    image.convert("RGB").save(out)


def draw_table_preview(draw: ImageDraw.ImageDraw, table: dict[str, Any]) -> None:
    x = float(table["x"])
    y = float(table["y"])
    cols = int(table["cols"])
    rows = int(table["rows"])
    total_w = float(table["w"])
    total_h = float(table["h"])
    col_widths = table.get("col_widths") or [total_w / cols] * cols
    row_heights = table.get("row_heights") or [total_h / rows] * rows
    cell_text = table.get("cell_text", [])
    border = rgb_tuple(table.get("border", "#999999"))
    fill = rgb_tuple(table.get("fill", "#ffffff"))
    header_fill = rgb_tuple(table.get("header_fill", "#dcecff"))
    alt_fill = rgb_tuple(table.get("alt_fill", "#f4f8ff"))
    font = preview_font(table)
    yy = y
    for r in range(rows):
        xx = x
        for c in range(cols):
            cw = float(col_widths[c])
            rh = float(row_heights[r])
            bg = header_fill if r == 0 else (alt_fill if r % 2 == 0 else fill)
            draw.rectangle([xx, yy, xx + cw, yy + rh], fill=bg, outline=border, width=1)
            text = ""
            if r < len(cell_text) and c < len(cell_text[r]):
                text = str(cell_text[r][c])
            draw.text((xx + 6, yy + 6), text, font=font, fill=rgb_tuple(table.get("color", "#000000")))
            xx += cw
        yy += float(row_heights[r])


def add_freeform_polygon(slide: Any, scale: Scale, points: list[list[float]], fill: str, stroke: str, stroke_width: float) -> None:
    from pptx.dml.color import RGBColor
    from pptx.enum.dml import MSO_LINE

    first = points[0]
    builder = slide.shapes.build_freeform(scale.x(first[0]), scale.y(first[1]))
    for point in points[1:]:
        builder.add_line_segments([(scale.x(point[0]), scale.y(point[1]))], close=False)
    builder.add_line_segments([(scale.x(first[0]), scale.y(first[1]))], close=True)
    shape = builder.convert_to_shape()
    if fill == "none":
        shape.fill.background()
    else:
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(*rgb_tuple(fill))
    if stroke == "none":
        shape.line.fill.background()
        shape.line.dash_style = MSO_LINE.SOLID
    else:
        shape.line.color.rgb = RGBColor(*rgb_tuple(stroke))
        shape.line.width = scale.w(stroke_width)


def build_pptx(plan: dict[str, Any], workdir: Path, out: Path) -> dict[str, int]:
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Pt

    canvas = plan["canvas"]
    slide_w = int(DEFAULT_SLIDE_WIDTH_IN * EMU_PER_INCH)
    slide_h = int(DEFAULT_SLIDE_HEIGHT_IN * EMU_PER_INCH)
    scale = Scale(float(canvas["width"]), float(canvas["height"]), slide_w, slide_h)

    prs = Presentation()
    prs.slide_width = slide_w
    prs.slide_height = slide_h
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    bg = normalize_color(canvas.get("background", "#ffffff"), "#ffffff")
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = RGBColor(*rgb_tuple(bg, (255, 255, 255)))
    assets = asset_map(plan)
    counts = {"text": 0, "table": 0, "picture": 0, "shape": 0}

    for element in sorted_elements(plan):
        etype = element["type"]
        if etype == "rect":
            shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, scale.x(element["x"]), scale.y(element["y"]), scale.w(element["w"]), scale.h(element["h"]))
            apply_shape_style(shape, element)
            counts["shape"] += 1
        elif etype == "circle":
            r = float(element["r"])
            shape = slide.shapes.add_shape(MSO_SHAPE.OVAL, scale.x(element["cx"] - r), scale.y(element["cy"] - r), scale.w(2 * r), scale.h(2 * r))
            apply_shape_style(shape, element)
            counts["shape"] += 1
        elif etype == "line":
            shape = slide.shapes.add_connector(
                1,
                scale.x(element["x1"]),
                scale.y(element["y1"]),
                scale.x(element["x2"]),
                scale.y(element["y2"]),
            )
            shape.line.color.rgb = RGBColor(*rgb_tuple(element.get("stroke", "#000000")))
            shape.line.width = Pt(float(element.get("stroke_width", 1)))
            counts["shape"] += 1
        elif etype == "polygon":
            add_freeform_polygon(
                slide,
                scale,
                element["points"],
                normalize_color(element.get("fill", "#ffffff")),
                normalize_color(element.get("stroke", "none")),
                float(element.get("stroke_width", 0)),
            )
            counts["shape"] += 1
        elif etype == "parallelogram":
            x, y, w, h = [float(element[key]) for key in ("x", "y", "w", "h")]
            skew = float(element.get("skew", 0))
            points = [[x + skew, y], [x + w + skew, y], [x + w, y + h], [x, y + h]]
            add_freeform_polygon(
                slide,
                scale,
                points,
                normalize_color(element.get("fill", "#ffffff")),
                normalize_color(element.get("stroke", "none")),
                float(element.get("stroke_width", 0)),
            )
            counts["shape"] += 1
        elif etype == "image":
            asset = assets.get(element.get("asset_id"), {})
            href = asset.get("file") or element.get("file")
            if not href:
                continue
            img_path = workdir / href
            if not img_path.exists():
                raise FileNotFoundError(f"Missing image asset: {img_path}")
            slide.shapes.add_picture(str(img_path), scale.x(element["x"]), scale.y(element["y"]), scale.w(element["w"]), scale.h(element["h"]))
            counts["picture"] += 1
        elif etype == "text":
            box = slide.shapes.add_textbox(scale.x(element["x"]), scale.y(element["y"]), scale.w(element["w"]), scale.h(element["h"]))
            text_frame = box.text_frame
            text_frame.clear()
            text_frame.margin_left = 0
            text_frame.margin_right = 0
            text_frame.margin_top = 0
            text_frame.margin_bottom = 0
            text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE if element.get("valign") == "middle" else MSO_ANCHOR.TOP
            lines = str(element.get("text", "")).splitlines() or [""]
            for idx, line in enumerate(lines):
                para = text_frame.paragraphs[0] if idx == 0 else text_frame.add_paragraph()
                para.text = line
                para.alignment = {
                    "center": PP_ALIGN.CENTER,
                    "right": PP_ALIGN.RIGHT,
                    "left": PP_ALIGN.LEFT,
                }.get(element.get("align", "left"), PP_ALIGN.LEFT)
                para.line_spacing = float(element.get("line_spacing", 1.0))
                for run in para.runs:
                    font = run.font
                    font.name = element.get("font_family", "Microsoft YaHei")
                    font.size = Pt(float(element.get("font_size", 16)))
                    font.bold = bool(element.get("bold", False))
                    font.italic = bool(element.get("italic", False))
                    font.color.rgb = RGBColor(*rgb_tuple(element.get("color", "#000000")))
            counts["text"] += 1
        elif etype == "table":
            add_table(slide, scale, element)
            counts["table"] += 1

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return counts


def apply_shape_style(shape: Any, element: dict[str, Any]) -> None:
    from pptx.dml.color import RGBColor
    from pptx.util import Pt

    fill = normalize_color(element.get("fill", "none"))
    stroke = normalize_color(element.get("stroke", "none"))
    if fill == "none":
        shape.fill.background()
    else:
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(*rgb_tuple(fill))
    if stroke == "none":
        shape.line.fill.background()
    else:
        shape.line.color.rgb = RGBColor(*rgb_tuple(stroke))
        shape.line.width = Pt(float(element.get("stroke_width", 1)))


def add_table(slide: Any, scale: Scale, element: dict[str, Any]) -> None:
    from pptx.dml.color import RGBColor
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Pt

    rows = int(element["rows"])
    cols = int(element["cols"])
    shape = slide.shapes.add_table(rows, cols, scale.x(element["x"]), scale.y(element["y"]), scale.w(element["w"]), scale.h(element["h"]))
    table = shape.table
    col_widths = element.get("col_widths")
    row_heights = element.get("row_heights")
    if col_widths:
        for idx, width in enumerate(col_widths[:cols]):
            table.columns[idx].width = scale.w(float(width))
    if row_heights:
        for idx, height in enumerate(row_heights[:rows]):
            table.rows[idx].height = scale.h(float(height))
    cell_text = element.get("cell_text", [])
    fill = normalize_color(element.get("fill", "#ffffff"))
    header_fill = normalize_color(element.get("header_fill", fill))
    alt_fill = normalize_color(element.get("alt_fill", fill))
    border = normalize_color(element.get("border", "#999999"))
    for r in range(rows):
        for c in range(cols):
            cell = table.cell(r, c)
            bg = header_fill if r == 0 else (alt_fill if r % 2 == 0 else fill)
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(*rgb_tuple(bg))
            text = ""
            if r < len(cell_text) and c < len(cell_text[r]):
                text = str(cell_text[r][c])
            frame = cell.text_frame
            frame.clear()
            frame.margin_left = Pt(float(element.get("cell_margin", 4)))
            frame.margin_right = Pt(float(element.get("cell_margin", 4)))
            frame.margin_top = Pt(float(element.get("cell_margin", 4)))
            frame.margin_bottom = Pt(float(element.get("cell_margin", 4)))
            frame.vertical_anchor = MSO_ANCHOR.MIDDLE
            para = frame.paragraphs[0]
            para.text = text
            para.alignment = PP_ALIGN.CENTER if element.get("align", "center") == "center" else PP_ALIGN.LEFT
            for run in para.runs:
                run.font.name = element.get("font_family", "Microsoft YaHei")
                run.font.size = Pt(float(element.get("font_size", 12)))
                run.font.bold = bool(element.get("header_bold", True) and r == 0)
                run.font.color.rgb = RGBColor(*rgb_tuple(element.get("color", "#000000")))
            for side in ("left", "right", "top", "bottom"):
                tc_pr = cell._tc.get_or_add_tcPr()
                # python-pptx has no public table border API; XML border detail is
                # intentionally left to advanced per-project patches.
                _ = tc_pr, side, border


def write_qa_report(path: Path, plan: dict[str, Any], counts: dict[str, int], created_assets: list[Path], validation: dict[str, Any]) -> None:
    editable = [e for e in plan.get("elements", []) if e.get("editable")]
    fallback = [e for e in plan.get("elements", []) if e.get("fallback") or e.get("needs_review")]
    asset_elements = [e for e in plan.get("elements", []) if e.get("asset") or e.get("type") == "image"]
    lines = [
        "# QA Report",
        "",
        f"- Slide id: `{plan.get('slide_id', 'unknown')}`",
        f"- Canvas: `{plan['canvas']['width']}x{plan['canvas']['height']}`",
        f"- Editable elements: `{len(editable)}`",
        f"- Image-backed elements: `{len(asset_elements)}`",
        f"- Fallback or review elements: `{len(fallback)}`",
        f"- PPT shape counts: `{counts}`",
        f"- Cropped/copied assets: `{len(created_assets)}`",
        f"- ZIP validation: `{validation.get('zip_ok')}`",
        f"- python-pptx validation: `{validation.get('pptx_ok')}`",
        "",
        "## Fallback / Needs Review",
    ]
    if fallback:
        for item in fallback:
            lines.append(f"- `{item.get('id', item.get('type'))}`: {item.get('text', item.get('asset_id', 'review'))}")
    else:
        lines.append("- None recorded.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def validate_pptx(path: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"pptx": str(path), "zip_ok": False, "pptx_ok": False}
    try:
        with zipfile.ZipFile(path, "r") as archive:
            bad = archive.testzip()
        result["zip_ok"] = bad is None
        result["zip_bad_file"] = bad
    except Exception as exc:  # pragma: no cover - diagnostic path
        result["zip_error"] = str(exc)
    try:
        from pptx import Presentation

        prs = Presentation(str(path))
        result["pptx_ok"] = True
        result["slides"] = len(prs.slides)
        result["slide_width"] = prs.slide_width
        result["slide_height"] = prs.slide_height
        result["shape_count"] = sum(len(slide.shapes) for slide in prs.slides)
        result["text_shape_count"] = sum(1 for slide in prs.slides for shape in slide.shapes if getattr(shape, "has_text_frame", False))
        result["table_count"] = sum(1 for slide in prs.slides for shape in slide.shapes if getattr(shape, "has_table", False))
        result["picture_count"] = sum(1 for slide in prs.slides for shape in slide.shapes if getattr(shape, "shape_type", None) == 13)
    except Exception as exc:  # pragma: no cover - diagnostic path
        result["pptx_error"] = str(exc)
    return result


def make_contact_sheet(source: Path, preview: Path, out: Path) -> None:
    src = Image.open(source).convert("RGB")
    pre = Image.open(preview).convert("RGB")
    width = max(src.width, pre.width)
    pad = 24
    label_h = 34
    sheet = Image.new("RGB", (width * 2 + pad * 3, max(src.height, pre.height) + label_h + pad * 2), "white")
    draw = ImageDraw.Draw(sheet)
    sheet.paste(src, (pad, pad + label_h))
    sheet.paste(pre, (width + pad * 2, pad + label_h))
    draw.text((pad, pad), "source", fill=(0, 0, 0))
    draw.text((width + pad * 2, pad), "preview", fill=(0, 0, 0))
    out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out)


def probe_renderers() -> dict[str, Any]:
    names = ["soffice", "libreoffice", "powerpnt"]
    found: dict[str, Any] = {}
    for name in names:
        found[name] = shutil.which(name)
    try:
        import win32com.client  # type: ignore  # noqa: F401

        found["win32com"] = True
    except Exception as exc:
        found["win32com"] = False
        found["win32com_error"] = str(exc)
    return found


def command_run(args: argparse.Namespace) -> int:
    plan_path = Path(args.plan)
    workdir = Path(args.workdir) if args.workdir else plan_path.parent
    source = Path(args.source) if args.source else None
    plan = load_plan(plan_path)
    workdir.mkdir(parents=True, exist_ok=True)
    created = crop_assets(plan, source, workdir)
    svg_path = Path(args.svg) if args.svg else workdir / "reconstruction.svg"
    preview_path = Path(args.preview) if args.preview else workdir / "preview.png"
    pptx_path = Path(args.pptx) if args.pptx else workdir / "reconstructed.pptx"
    write_svg(plan, workdir, svg_path)
    write_preview(plan, workdir, preview_path)
    counts = build_pptx(plan, workdir, pptx_path)
    validation = validate_pptx(pptx_path)
    write_json(workdir / "validation.json", validation)
    write_qa_report(workdir / "qa_report.md", plan, counts, created, validation)
    if source:
        make_contact_sheet(source, preview_path, workdir / "comparison_contact_sheet.png")
    print(json.dumps({"pptx": str(pptx_path), "preview": str(preview_path), "validation": validation}, ensure_ascii=False, indent=2))
    return 0 if validation.get("zip_ok") and validation.get("pptx_ok") else 1


def command_validate(args: argparse.Namespace) -> int:
    result = validate_pptx(Path(args.pptx))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("zip_ok") and result.get("pptx_ok") else 1


def command_probe_renderers(_: argparse.Namespace) -> int:
    print(json.dumps(probe_renderers(), ensure_ascii=False, indent=2))
    return 0


def command_contact_sheet(args: argparse.Namespace) -> int:
    make_contact_sheet(Path(args.source), Path(args.preview), Path(args.out))
    print(args.out)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build editable PPT artifacts from an image-to-ppt-pro layout plan.")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="Create crops, SVG, preview, PPTX, validation, and QA report.")
    run.add_argument("--plan", required=True, help="Path to layout_plan.json")
    run.add_argument("--source", help="Source image for asset crops")
    run.add_argument("--workdir", help="Slide work directory; defaults to plan parent")
    run.add_argument("--svg", help="Output SVG path")
    run.add_argument("--preview", help="Output preview PNG path")
    run.add_argument("--pptx", help="Output PPTX path")
    run.set_defaults(func=command_run)

    validate = sub.add_parser("validate", help="Validate a PPTX with zipfile and python-pptx.")
    validate.add_argument("--pptx", required=True)
    validate.set_defaults(func=command_validate)

    probe = sub.add_parser("probe-renderers", help="Report optional PowerPoint/LibreOffice renderer availability.")
    probe.set_defaults(func=command_probe_renderers)

    contact = sub.add_parser("contact-sheet", help="Create a source/preview comparison image.")
    contact.add_argument("--source", required=True)
    contact.add_argument("--preview", required=True)
    contact.add_argument("--out", required=True)
    contact.set_defaults(func=command_contact_sheet)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

