# Image To PPT Pro Workflow

This workflow is for raster slide images, screenshots, academic report pages, and image-only decks that need to become editable PowerPoint files.

## 1. Scope And Fidelity Contract

Before editing, decide what "editable" means for the job:

- Core editable content: titles, subtitles, body text, bullets, section labels, table text, table grid, simple lines, simple shapes, and simple callouts.
- Image-backed content: photos, school/company logos, complex pictograms, noisy textures, screenshots inside the slide, and dense decorative background regions.
- Fallback content: tiny labels or highly stylized glyphs that would look worse if forced into editable text. Mark these in QA.

Default mode is balanced editable reconstruction. Switch to high-fidelity mode when the user points out visual mismatch, ghosting, broken icons, or dirty background removal.

## 2. Workspace Layout

Use a deterministic output folder. For a three-slide experiment, for example:

```text
editable_ppt_experiment_v3/
  slide_01_cover/
    layout_plan.json
    reconstruction.svg
    preview.png
    reconstructed.pptx
    qa_report.md
    assets/
  slide_02_toc/
  slide_26_methods/
  sample_3slides_editable_v3.pptx
  comparison_contact_sheet_v3.png
  validation_v3.json
  qa_summary_v3.md
```

Keep older versions instead of overwriting them when iterating on quality.

## 3. Dependency Check

Required:

```powershell
python --version
python -c "import PIL, pptx, lxml; print('core ok')"
```

Recommended:

```powershell
tesseract --version
tesseract --list-langs
python -c "import pytesseract, cv2, numpy; print('ocr ok')"
```

Optional renderer probes:

```powershell
where.exe soffice
where.exe libreoffice
where.exe powerpnt
python -c "import win32com.client; print('com ok')"
```

If CairoSVG fails because native Cairo DLLs are unavailable, keep using Pillow previews and SVG inspection. Do not block the reconstruction on Cairo.

## 4. OCR And Manual Text Proofing

OCR is only a draft source. Always manually proof:

- Chinese titles and section labels.
- English subtitles.
- Names, course titles, dates, and page numbers.
- Table headers and every table cell.
- Similar-looking punctuation and digits.

If text cannot be confidently read, add `needs_review: true` in the plan and mention it in QA instead of inventing content.

## 5. Layout Plan

Use source-image pixel coordinates. Keep the plan semantic and stable:

- `text`: editable text box.
- `rect`, `line`, `circle`: editable shapes.
- `polygon`, `parallelogram`: editable freeform-like or polygon approximation.
- `image`: independent cropped asset or local background plate.
- `table`: native PowerPoint table when true cell editing matters.

Every element should state one of:

- `editable: true`
- `asset: true`
- `fallback: true`

Use `z` values or list order to make layering explicit.

## 6. Asset Cropping

Crop assets from the source image with safe padding:

- Logos: include enough surrounding pixels to avoid clipped strokes.
- Photos: prefer one large clean crop over many overlapping fragments.
- Small icons: crop the whole icon badge when reconstructing the glyph breaks it.
- Background plates: crop local regions only where they improve fidelity and do not make the whole slide flat.

For logos on white or near-white backgrounds, remove near-white pixels or set them transparent if the logo has a rectangular box.

## 7. Rebuild Order

Recommended layer order:

1. Solid background color.
2. Large photo/background plates.
3. Diagonal wedges, masks, and section fills.
4. Decorative lines and simple geometry.
5. Image-backed logos/icons.
6. Editable table grid and shapes.
7. Editable text.

For ghosting fixes, place clean masks or background plates below corrected editable text and above the noisy source area.

## 8. Iteration Strategy

Generate the preview, compare against the source, then adjust:

- Geometry: x/y/w/h, diagonal edges, crop positions, and z-order.
- Typography: family, size, weight, color, line spacing, width, and alignment.
- Tables: column widths, row heights, fills, border color, and cell padding.
- Assets: crop boundary, transparency threshold, and safe padding.

When comments point to a selected PPT element, fix the matching plan element or generation code, then regenerate instead of editing the PPT manually.

## 9. Validation

Always run:

```powershell
python -m zipfile -t path\to\deck.pptx
python -c "from pptx import Presentation; p=Presentation(r'path\to\deck.pptx'); print(len(p.slides), p.slide_width, p.slide_height)"
```

Also inspect counts of text boxes, tables, and pictures when the user cares about editability.

If PowerPoint or LibreOffice rendering is unavailable, say so in QA and use `preview.png` plus manual PPT opening as the visual check.

