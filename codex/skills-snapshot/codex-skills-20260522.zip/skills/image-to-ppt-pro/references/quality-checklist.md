# Quality Checklist

Use this checklist before delivering a reconstructed PPTX, and again after user review comments.

## Visual Similarity

- Slide size matches the source aspect ratio, usually 16:9.
- Main visual regions align within a few pixels in the preview.
- Large diagonal decorations have clean edges.
- Photos are not accidentally stretched, clipped, or split into visible fragments.
- Crops include safe padding so strokes and antialiased edges are intact.
- No accidental rectangular boxes around logos or icons.

## Editability

- Main title and subtitles are editable text.
- Body text, TOC entries, captions, dates, names, and course labels are editable unless explicitly documented as fallback.
- Tables are native PowerPoint tables when real cell editing is expected.
- Simple shapes and lines are editable PowerPoint objects.
- Photos, logos, and complex icons are independent movable image objects, not one full-slide flat background.

## Typography

- Chinese font defaults to `Microsoft YaHei` or `Microsoft YaHei UI`.
- English can use `Arial`, `Aptos`, or a source-matched sans serif.
- Large titles are split into multiple text boxes when needed to avoid line-height and width compromises.
- No text is clipped, overlapped, or wrapped unexpectedly.
- Bold, color, alignment, and line spacing match the source closely enough for the task.

## Ghosting And Dirty Background Fixes

- Do not leave source text visible below editable replacement text.
- Do not use blurry inpaint patches when a clean mask or crop plate can solve it.
- Use source-matched white/light masks over old text, then place editable text above.
- For slanted cover designs, use a clean photo crop plus editable white/blue wedges to hide old fragments.
- If a tiny label still looks wrong as editable text, switch it to a clean image crop and document that it is image-backed.

## Logos And Icons

- Logo background blends with the slide background.
- Near-white pixels are transparent or visually invisible when the logo sits on white.
- Small icon badges are cropped as intact groups when glyph reconstruction fragments them.
- Icon crops have 2-4 px padding.
- If a logo is a brand mark, avoid low-quality vector tracing unless the user provides the vector source.

## Tables

- Column widths and row heights match the source.
- Header/background fills use the original light/dark rhythm.
- Borders are not too thick.
- Cell padding is compact and consistent.
- Text baseline and wrapping are visually stable.
- All table cell text remains editable unless documented.

## Validation Commands

```powershell
python -m zipfile -t path\to\deck.pptx
python -c "from pptx import Presentation; p=Presentation(r'path\to\deck.pptx'); print(len(p.slides), p.slide_width, p.slide_height)"
```

Recommended builder checks:

```powershell
python scripts\build_image_to_ppt_pro.py validate --pptx path\to\deck.pptx
python scripts\build_image_to_ppt_pro.py probe-renderers
```

## QA Report Minimum

Include:

- Source image path and size.
- Output PPTX path.
- Number of editable text objects, tables, shapes, and image assets.
- Which regions are image-backed and why.
- Renderer availability.
- Known issues and `needs_review` text.
- Manual checks performed.

