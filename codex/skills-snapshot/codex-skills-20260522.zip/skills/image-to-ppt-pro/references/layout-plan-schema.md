# Layout Plan Schema

The layout plan is JSON in source-image pixel coordinates. It should be readable enough for manual review and deterministic enough for regeneration.

## Top-Level Shape

```json
{
  "schema_version": "image-to-ppt-pro/v1",
  "slide_id": "slide_01_cover",
  "canvas": {
    "width": 1672,
    "height": 941,
    "background": "#ffffff"
  },
  "notes": ["optional reviewer notes"],
  "assets": [],
  "elements": []
}
```

## Asset Entries

Assets may point to files that already exist or to source crops the builder should create.

```json
{
  "id": "campus_photo",
  "file": "assets/campus_photo.png",
  "source_box": [960, 0, 712, 941],
  "padding": 3,
  "transparent_near_white": false,
  "role": "photo"
}
```

For a logo that needs to blend into a white background:

```json
{
  "id": "logo_top_right",
  "file": "assets/logo_top_right.png",
  "source_box": [1030, 22, 222, 55],
  "padding": 4,
  "transparent_near_white": true,
  "near_white_threshold": 245,
  "role": "logo"
}
```

## Text

```json
{
  "type": "text",
  "id": "main_title_1",
  "x": 80,
  "y": 350,
  "w": 720,
  "h": 80,
  "text": "Diffusion Models",
  "font_family": "Microsoft YaHei",
  "font_size": 44,
  "bold": true,
  "color": "#0a3a8a",
  "align": "left",
  "valign": "top",
  "line_spacing": 1.05,
  "editable": true,
  "z": 50
}
```

Use separate text boxes when a large title needs independent line spacing or exact visual placement.

## Rect

```json
{
  "type": "rect",
  "id": "bottom_band",
  "x": 0,
  "y": 795,
  "w": 790,
  "h": 146,
  "fill": "#00479d",
  "stroke": "none",
  "editable": true,
  "z": 5
}
```

## Line

```json
{
  "type": "line",
  "id": "title_rule",
  "x1": 80,
  "y1": 620,
  "x2": 872,
  "y2": 620,
  "stroke": "#d4dbe7",
  "stroke_width": 1,
  "editable": true,
  "z": 20
}
```

## Circle

```json
{
  "type": "circle",
  "id": "step_badge",
  "cx": 220,
  "cy": 410,
  "r": 24,
  "fill": "#0b56aa",
  "stroke": "#ffffff",
  "stroke_width": 2,
  "editable": true,
  "z": 20
}
```

## Image

```json
{
  "type": "image",
  "id": "campus_photo_on_slide",
  "asset_id": "campus_photo",
  "x": 890,
  "y": 0,
  "w": 782,
  "h": 941,
  "crop_polygon": [[980, 0], [1672, 0], [1518, 941], [800, 941]],
  "asset": true,
  "z": 2
}
```

`crop_polygon` is a semantic hint. Some builders may approximate it with a crop plus foreground masks because PowerPoint image clipping support is limited.

## Polygon And Parallelogram

```json
{
  "type": "polygon",
  "id": "white_wedge",
  "points": [[708, 941], [1220, 0], [1285, 0], [805, 941]],
  "fill": "#ffffff",
  "stroke": "none",
  "editable": true,
  "z": 10
}
```

For simple slanted bands:

```json
{
  "type": "parallelogram",
  "id": "blue_slash",
  "x": 1490,
  "y": 0,
  "w": 160,
  "h": 941,
  "skew": -120,
  "fill": "#00479d",
  "stroke": "none",
  "editable": true,
  "z": 12
}
```

## Table

Use a table element when cell editing matters.

```json
{
  "type": "table",
  "id": "method_compare",
  "x": 90,
  "y": 160,
  "w": 1490,
  "h": 620,
  "rows": 6,
  "cols": 5,
  "col_widths": [250, 330, 300, 300, 310],
  "row_heights": [58, 110, 110, 110, 110, 122],
  "cell_text": [
    ["Method", "Principle", "Strength", "Weakness", "Use Case"]
  ],
  "font_family": "Microsoft YaHei",
  "font_size": 13,
  "fill": "#ffffff",
  "header_fill": "#dcecff",
  "alt_fill": "#f4f8ff",
  "border": "#7fa8d8",
  "editable": true,
  "z": 30
}
```

If a table cell contains a formula-like expression, proof it manually and keep it as plain editable text unless the user asks for equation objects.

