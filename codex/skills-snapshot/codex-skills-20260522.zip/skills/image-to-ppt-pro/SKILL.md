---
name: image-to-ppt-pro
description: Use when converting raster slide images, PPT screenshots, academic presentation images, report pages, posters, or image-only decks into high-fidelity editable PowerPoint files with semantic layout plans, cropped assets, OCR drafts, SVG/PPTX reconstruction, previews, and QA validation.
metadata:
  short-description: Rebuild slide images as editable PPT
---

# Image To PPT Pro

## Overview

Use this skill to turn one or more slide/page images into a practical editable PowerPoint deck. Prefer semantic reconstruction: text, tables, grids, lines, and simple geometry become PowerPoint-native objects; photos, logos, complex icons, and noisy backgrounds become clean independent image assets.

The goal is not maximum vectorization at any cost. The goal is a deck that visually matches the source while keeping the content users actually need to edit editable.

## Decision Tree

1. If the user wants editable PPT from images, use this skill.
2. If the source is a screenshot of a slide, academic page, report page, or table-heavy image, use the semantic layout workflow in `references/workflow.md`.
3. If the user complains about ghosted fonts, dirty background removal, broken icons, or fragmented shapes, switch to high-fidelity mode from `references/quality-checklist.md`.
4. If exact visual matching matters more than editability, use local cropped background plates for complex regions, but still keep the main title/body/table text editable.
5. Only use a whole-slide flat image as the final sole content when the user explicitly asks for visual-only output.

## Default Deliverables

For each input slide image, create a slide work folder containing:

- `layout_plan.json`: semantic layout in source-image pixel coordinates.
- `assets/`: cropped photos, logos, complex icons, and local background plates.
- `reconstruction.svg`: inspectable intermediate reconstruction.
- `preview.png`: local visual preview rendered from the plan.
- `reconstructed.pptx`: one-slide editable reconstruction.
- `qa_report.md`: what is editable, what is image-backed, renderer status, and known compromises.

For multi-slide jobs, also create:

- `sample_editable.pptx` or a user-specific deck name.
- `comparison_contact_sheet.png` with source and preview side by side.
- `validation.json` or `qa_summary.md`.

## Core Workflow

1. Inspect every source image: dimensions, aspect ratio, dominant regions, text/table density, and likely asset crops.
2. Verify dependencies: Python, Pillow, python-pptx, lxml, and optionally Tesseract, pytesseract, OpenCV, and a renderer such as PowerPoint or LibreOffice.
3. Run OCR only as a draft. Manually proof all visible text, especially Chinese, numerals, dates, section labels, and table cells.
4. Create `layout_plan.json` using pixel coordinates from the original image. Use only stable element types: `text`, `rect`, `line`, `circle`, `image`, `table`, `polygon`, and `parallelogram`.
5. Crop assets with 2-4 px safe padding. For complex logos or tiny pictograms, prefer intact image crops over fragile glyph/vector reconstruction.
6. Rebuild the slide from the plan, using native PowerPoint text boxes, shapes, and tables where they are genuinely editable.
7. Generate SVG and preview PNG for fast visual checks. Render the PPTX to PNG with PowerPoint COM or LibreOffice when available.
8. Iterate from actual comments: fix text, font size, line spacing, asset crop boundaries, masks, transparency, and z-order.
9. Validate the final deck with ZIP integrity and `python-pptx` shape inspection before reporting completion.

## High-Fidelity Rules

Use these rules when visual similarity is more important than making every decoration editable:

- Fix font ghosting by covering the source text area with clean editable masks or source-matched plates, then place corrected editable text on top. Avoid blurry inpainting patches.
- For logos on white or near-white backgrounds, remove or soften near-white pixels so the logo blends into the slide background.
- For complex icons, use the full circular/icon group crop instead of splitting it into font glyphs and partial shapes.
- For photos and diagonal slide decorations, prefer a complete clean crop plus editable cover shapes over many small clipped fragments.
- For tables, use a native PowerPoint table when the user needs real cell editing; otherwise use a stable shape grid with editable text boxes only if it matches the original better.
- For very small problematic labels, allow image-backed text only after documenting the tradeoff in `qa_report.md`.

## Useful Resources

- `references/workflow.md`: full production workflow and iteration strategy.
- `references/layout-plan-schema.md`: layout plan schema and examples.
- `references/quality-checklist.md`: QA checklist and fixes for common visual defects.
- `scripts/build_image_to_ppt_pro.py`: reusable builder for plan-based SVG, preview, PPTX, crops, contact sheets, and validation.

